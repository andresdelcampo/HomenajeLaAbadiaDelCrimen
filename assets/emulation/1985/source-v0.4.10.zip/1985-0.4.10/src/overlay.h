#pragma once
#include <stdbool.h>
#include <SDL3/SDL.h>
#include "config.h"
#include "disk.h"

typedef enum {
    OV_GENERAL    = 0,
    OV_MEDIA      = 1,
    OV_EXTENSIONS = 2,
    OV_TINKER     = 3,
    OV_SEC_COUNT  = 4
} OvSection;

typedef enum {
    OV_STATE_MENU         = 0,
    OV_STATE_CONFIRM      = 1,
    OV_STATE_KEYS         = 2,
    OV_STATE_EDIT         = 3,
    OV_STATE_EDIT_CONFIRM = 4,
    OV_STATE_FILE_BROWSER = 5,
    OV_STATE_ABOUT        = 6,   /* About dialog with an OK button */
} OvState;

typedef enum {
    DIALOG_NONE          = 0,
    DIALOG_DISK          = 1,
    DIALOG_SNAPSHOT_LOAD = 2,
    DIALOG_SNAPSHOT_SAVE = 3,
    DIALOG_PRINT_DIR     = 4,
    DIALOG_DISK_NEW      = 5,   /* save dialog → disk_create_blank */
    DIALOG_BOOT_ROM_DIR  = 6,   /* folder picker → cfg->boot_rom_dir */
} DialogKind;

struct PCW;
struct Display;
struct OverlayBrowserEntry;

typedef struct {
    bool        visible;
    OvSection   section;
    int         row;
    OvState     state;
    bool        dirty;
    Config     *cfg;
    Config      saved;
    struct PCW *pcw;
    struct Display *disp;
    /* pending file-dialog result */
    DialogKind  dialog_kind;
    int         dialog_drive;    /* 0=A, 1=B */
    DiskType    dialog_disk_type;/* format for an in-flight DIALOG_DISK_NEW */
    char        dialog_path[PATH_MAX];
    bool        dialog_ready;
    bool        dialog_failed;
    char        dialog_error[256];
    bool        needs_cold_boot;
    /* Built-in SDL-rendered disk browser. This is forced by --sdl-fm,
     * available directly with Shift+Enter, and used automatically if
     * the native file-dialog provider reports an error. */
    bool        sdl_fm;
    int         browser_drive;
    char        browser_dir[PATH_MAX];
    char        browser_error[256];
    struct OverlayBrowserEntry *browser_entries;
    int         browser_entry_count;
    int         browser_entry_capacity;
    int         browser_row;
    int         browser_scroll;
    /* Inline text editor state (OV_STATE_EDIT). The target field a
     * commit writes back to is identified by `edit_target`. */
    char        edit_buf [PATH_MAX];
    char        edit_orig[PATH_MAX];
    int         edit_target;     /* e.g. 1 = ext_serial_pty_link */
} Overlay;

void overlay_init(Overlay *ov, Config *cfg, struct PCW *pcw,
                  struct Display *disp, bool sdl_fm);
void overlay_quit(Overlay *ov);

bool overlay_handle_event(Overlay *ov, SDL_Event *ev);
void overlay_render(Overlay *ov, SDL_Renderer *r);
void overlay_tick  (Overlay *ov);
