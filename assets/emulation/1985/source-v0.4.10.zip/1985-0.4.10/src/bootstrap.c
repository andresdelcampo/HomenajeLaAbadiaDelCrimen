#include "bootstrap.h"
#include <SDL3/SDL_filesystem.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* PCW boot ROM — 275 bytes shifted out of the printer-MCU into low RAM
 * at reset. On hardware this is mask-programmed into the 8041AH; here
 * we either load it from `roms/pcw_boot.rom` at startup or, if that
 * file is missing, fall back to the embedded copy below.
 *
 * Bytes are identical to Joyce's `pcw_boot.rom` and MAME's PCW
 * printer-MCU dump. The first instruction is JP 0x0102, so the entry
 * point is at offset 0x0102 in this image. */
static const u8 PCW_BOOT_ROM[] = {
    0xc3, 0x02, 0x01, 0xf3, 0x83, 0xed, 0x41, 0x0d, 0x78, 0x05, 0x87, 0x20, 0xf8, 0x31, 0xf0, 0xff,
    0x3e, 0x09, 0xd3, 0xf8, 0x11, 0x32, 0x07, 0x06, 0xc8, 0xdc, 0xb1, 0x00, 0xcd, 0x84, 0x00, 0x1d,
    0xf2, 0x17, 0x00, 0x3e, 0x80, 0xd3, 0xf7, 0x0e, 0x09, 0x0c, 0x79, 0xd3, 0xf8, 0x06, 0x21, 0xcd,
    0xb1, 0x00, 0xcb, 0x51, 0x20, 0xf1, 0x15, 0x20, 0xf0, 0x21, 0xf5, 0xff, 0x77, 0xcb, 0x7e, 0x28,
    0xfc, 0x3c, 0xd3, 0xf8, 0x1d, 0x1d, 0x3e, 0x06, 0xd3, 0xf8, 0xcd, 0xe4, 0x00, 0x09, 0x66, 0x00,
    0x00, 0x00, 0x01, 0x02, 0x01, 0x2a, 0xff, 0x21, 0x00, 0xf0, 0xdb, 0x00, 0x87, 0x30, 0xfb, 0x87,
    0xf2, 0x6b, 0x00, 0xed, 0xa2, 0x20, 0xf3, 0x7c, 0x1f, 0x38, 0xef, 0x3e, 0x05, 0xd3, 0xf8, 0xcd,
    0xc7, 0x00, 0xe6, 0xcb, 0xc0, 0x47, 0x21, 0x10, 0xf0, 0x24, 0x86, 0x25, 0x86, 0x2c, 0x10, 0xf9,
    0x3c, 0x20, 0xa0, 0xe9, 0x0e, 0x80, 0xcd, 0xdb, 0x00, 0x05, 0x03, 0x0f, 0xff, 0x07, 0x00, 0xcd,
    0xa5, 0x00, 0x06, 0xc8, 0x38, 0x1b, 0xcd, 0x44, 0x00, 0xcd, 0x44, 0x00, 0x0e, 0x00, 0xcd, 0xdb,
    0x00, 0x03, 0x0f, 0x00, 0x14, 0xcd, 0xbd, 0x00, 0x30, 0xfb, 0x17, 0x38, 0xf8, 0x17, 0xd8, 0x06,
    0x14, 0x3e, 0xb3, 0xe3, 0xe3, 0xe3, 0xe3, 0x3d, 0x20, 0xf9, 0x10, 0xf5, 0xc9, 0xdb, 0xf8, 0xe6,
    0x20, 0xc8, 0xcd, 0xe9, 0x00, 0x01, 0x08, 0x21, 0x02, 0x01, 0xdb, 0x00, 0x87, 0x30, 0xfb, 0x3a,
    0x02, 0x01, 0xf0, 0xed, 0xa2, 0xe3, 0xe3, 0xe3, 0xe3, 0x18, 0xef, 0xdb, 0xf8, 0xe6, 0x40, 0x28,
    0xfa, 0x79, 0xd3, 0xf7, 0xcd, 0xbd, 0x00, 0x38, 0xfb, 0xe3, 0x46, 0x23, 0xe3, 0x0e, 0x01, 0xe3,
    0xdb, 0x00, 0x87, 0x30, 0xfb, 0xfa, 0xfb, 0x00, 0x7e, 0xed, 0x79, 0x23, 0xe3, 0xe3, 0xe3, 0x10,
    0xee, 0xc9, 0xaf, 0xd3, 0xf0, 0x01, 0x00, 0x00, 0x3e, 0xd3, 0x02, 0x03, 0x3e, 0xf8, 0x02, 0xaf,
    0xc3, 0x00, 0x00
};

/* Try a single candidate path. Returns bytes read (0 on miss). On
 * success the path is copied into `chosen` so the caller can report it. */
static int try_rom(const char *path, u8 *out, int max_len,
                   char *chosen, size_t chosen_cap) {
    if (!path || !path[0]) return 0;
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    int n = (int)fread(out, 1, (size_t)max_len, f);
    fclose(f);
    if (n > 0 && n <= max_len) {
        if (chosen && chosen_cap) snprintf(chosen, chosen_cap, "%s", path);
        return n;
    }
    return 0;
}

/* Search the standard user-data locations for a `pcw_boot.rom` override,
 * falling back to the cwd (legacy behaviour) and finally to the embedded
 * copy via the caller. Order:
 *
 *   Linux/macOS:
 *     $XDG_DATA_HOME/1985/roms/pcw_boot.rom
 *     $HOME/.local/share/1985/roms/pcw_boot.rom
 *   Windows:
 *     %APPDATA%/1985/roms/pcw_boot.rom
 *   Always:
 *     <application base>/roms/pcw_boot.rom
 *     ./roms/pcw_boot.rom
 *     roms/pcw_boot.rom
 *
 * Lets users drop a custom ROM in a stable, per-user location without
 * needing to launch from the source tree. */
static int load_rom_file(u8 *out, int max_len,
                         char *chosen, size_t chosen_cap,
                         const char *override_dir) {
    char buf[1024];
    int n;

    /* User-specified override directory wins over everything. */
    if (override_dir && override_dir[0]) {
        snprintf(buf, sizeof(buf), "%s/pcw_boot.rom", override_dir);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }

#ifdef _WIN32
    const char *appdata = getenv("APPDATA");
    if (!appdata || !appdata[0]) appdata = getenv("LOCALAPPDATA");
    if (appdata && appdata[0]) {
        snprintf(buf, sizeof(buf), "%s/1985/roms/pcw_boot.rom", appdata);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }
#endif
    const char *xdg_data = getenv("XDG_DATA_HOME");
    if (xdg_data && xdg_data[0]) {
        snprintf(buf, sizeof(buf), "%s/1985/roms/pcw_boot.rom", xdg_data);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }
    const char *home = getenv("HOME");
    if (home && home[0]) {
        snprintf(buf, sizeof(buf),
                 "%s/.local/share/1985/roms/pcw_boot.rom", home);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }
    /* Friendly fallback: users who don't know the XDG split often
     * expect ROMs to live next to the config file. Check there too. */
    const char *xdg_config = getenv("XDG_CONFIG_HOME");
    if (xdg_config && xdg_config[0]) {
        snprintf(buf, sizeof(buf), "%s/1985/roms/pcw_boot.rom", xdg_config);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }
    if (home && home[0]) {
        snprintf(buf, sizeof(buf),
                 "%s/.config/1985/roms/pcw_boot.rom", home);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }
    const char *base = SDL_GetBasePath();
    if (base && base[0]) {
        snprintf(buf, sizeof(buf), "%sroms/pcw_boot.rom", base);
        if ((n = try_rom(buf, out, max_len, chosen, chosen_cap)) > 0) return n;
    }
    if ((n = try_rom("roms/pcw_boot.rom",   out, max_len, chosen, chosen_cap)) > 0) return n;
    if ((n = try_rom("./roms/pcw_boot.rom", out, max_len, chosen, chosen_cap)) > 0) return n;
    return 0;
}

void bootstrap_init(Bootstrap *b) {
    memset(b, 0, sizeof(*b));
    bootstrap_reset(b);
}

void bootstrap_reset(Bootstrap *b) {
    /* Prefer the on-disk ROM (lets users drop a different image in
     * one of the search paths without rebuilding); fall back to the
     * embedded copy so a stock checkout still boots out of the box. */
    b->source[0] = '\0';
    int n = load_rom_file(b->stream, (int)sizeof(b->stream),
                          b->source, sizeof(b->source),
                          b->override_dir);
    if (n <= 0) {
        n = (int)sizeof(PCW_BOOT_ROM);
        memcpy(b->stream, PCW_BOOT_ROM, (size_t)n);
        snprintf(b->source, sizeof(b->source), "embedded");
    }
    b->len    = n;
    b->active = true;
}

void bootstrap_set_override_dir(Bootstrap *b, const char *dir) {
    if (dir && dir[0])
        snprintf(b->override_dir, sizeof(b->override_dir), "%s", dir);
    else
        b->override_dir[0] = '\0';
}

bool bootstrap_active(const Bootstrap *b) {
    return b->active;
}

u8 bootstrap_read(const Bootstrap *b, u16 addr) {
    if (addr < b->len) return b->stream[addr];
    return 0x00;
}

void bootstrap_finish(Bootstrap *b) {
    b->active = false;
}
